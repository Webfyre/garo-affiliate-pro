<?php
/**
 * Garo Affiliate Pro - Default Settings and Config Flags
 * Location: /config/settings.php
 */

if (!defined('ABSPATH')) exit;

class Garo_Affiliate_Settings {

    public static function init() {
        add_action('admin_init', [__CLASS__, 'register_settings']);
    }

    /**
     * Register WP Settings API fields
     */
    public static function register_settings() {
        register_setting('garo_affiliate_settings_group', 'garo_affiliate_settings', [
            'type' => 'array',
            'sanitize_callback' => [__CLASS__, 'sanitize'],
            'default' => self::defaults(),
        ]);

        add_settings_section('garo_aff_general_section', 'General Settings', null, 'garo_affiliate_settings');

        add_settings_field('commission_base', 'Base Commission (%)', [__CLASS__, 'input_number'], 'garo_affiliate_settings', 'garo_aff_general_section', [
            'id' => 'commission_base',
            'min' => 0, 'max' => 100, 'step' => 0.01
        ]);

        add_settings_field('minimum_payout', 'Minimum Payout (KES)', [__CLASS__, 'input_number'], 'garo_affiliate_settings', 'garo_aff_general_section', [
            'id' => 'minimum_payout',
            'min' => 0, 'step' => 1
        ]);

        add_settings_field('cookie_days', 'Cookie Duration (Days)', [__CLASS__, 'input_number'], 'garo_affiliate_settings', 'garo_aff_general_section', [
            'id' => 'cookie_days', 'min' => 1, 'step' => 1
        ]);

        add_settings_field('support_email', 'Support Email', [__CLASS__, 'input_text'], 'garo_affiliate_settings', 'garo_aff_general_section', [
            'id' => 'support_email'
        ]);
    }

    public static function input_number($args) {
        $options = get_option('garo_affiliate_settings', self::defaults());
        $value = isset($options[$args['id']]) ? $options[$args['id']] : '';
        printf('<input type="number" name="garo_affiliate_settings[%s]" value="%s" min="%s" step="%s" />',
            esc_attr($args['id']), esc_attr($value), $args['min'], $args['step']);
    }

    public static function input_text($args) {
        $options = get_option('garo_affiliate_settings', self::defaults());
        $value = isset($options[$args['id']]) ? $options[$args['id']] : '';
        printf('<input type="text" name="garo_affiliate_settings[%s]" value="%s" class="regular-text" />',
            esc_attr($args['id']), esc_attr($value));
    }

    public static function sanitize($input) {
        $output = self::defaults();
        foreach ($output as $key => $default) {
            if (isset($input[$key])) {
                $output[$key] = sanitize_text_field($input[$key]);
            }
        }
        return $output;
    }

    public static function defaults() {
        return [
            'enabled'                => true,
            'commission_base'        => 5,    // stored as percent
            'super_affiliate_bonus'  => 3,
            'mlm_enabled'            => true,
            'mlm_level_2_bonus'      => 1,
            'minimum_payout'         => 1000,
            'currency'               => 'KES',
            'cookie_days'            => 30,
            'notify_on_signup'       => true,
            'notify_on_sale'         => true,
            'notify_on_payout'       => true,
            'fraud_checks'           => true,
            'ip_limit_per_referral'  => 2,
            'geo_check_enabled'      => true,
            'track_device'           => true,
            'track_browser'          => true,
            'dashboard_slug'         => 'affiliate-dashboard',
            'login_page_slug'        => 'affiliate-login',
            'register_page_slug'     => 'affiliate-register',
            'support_email'          => get_option('admin_email'),
        ];
    }

    public static function get($key) {
        $all = get_option('garo_affiliate_settings', self::defaults());
        return isset($all[$key]) ? $all[$key] : null;
    }

    public static function update($key, $value) {
        $all = get_option('garo_affiliate_settings', self::defaults());
        $all[$key] = $value;
        update_option('garo_affiliate_settings', $all);
    }

    public static function reset() {
        update_option('garo_affiliate_settings', self::defaults());
    }
}
